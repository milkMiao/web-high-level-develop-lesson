// function $(arg){
//     return {
//         click(cb){
//             document.querySelector(arg).onclick = cb;
//         }
//     }
// }
// const config = {
//     animationIterationCount: true,
//     columnCount: true,
//     fillOpacity: true,
//     flexGrow: true,
//     flexShrink: true,
//     fontWeight: true,
//     gridArea: true,
//     gridColumn: true,
//     gridColumnEnd: true,
//     gridColumnStart: true,
//     gridRow: true,
//     gridRowEnd: true,
//     gridRowStart: true,
//     lineHeight: true,
//     opacity: true,
//     order: true,
//     orphans: true,
//     widows: true,
//     zIndex: true,
//     zoom: true
// }

class Jq{
    constructor(arg,root){
        if(typeof root === "undefined"){
            this['prevObject'] = [document];
        }else{
            this['prevObject'] = root;
        }
        // 通过类型区分不同的情况分别处理
        if(typeof arg === "string"){
            // this.ele = document.querySelector(arg);
            // this[0] = ele1  this[1] = ele2 ....
            let eles = document.querySelectorAll(arg);
            this.#addEles(eles);
        }else if(typeof arg === "function"){
            document.addEventListener("DOMContentLoaded",arg);
        }else{
            // console.log(arg);
            if(typeof arg.length !== "undefined"){
                this.#addEles(arg);
            }else{
                this[0] = arg
                this.length = 1;
            }
        }
    }
    #addEles(eles){
        // console.log(eles)
        for(let i=0;i<eles.length;i++){
            this[i] = eles[i];
        }
        this.length = eles.length;
    }
    click(cb){
        // this.ele.addEventListener("click",cb);
        for(let i=0;i<this.length;i++){
            this[i].addEventListener("click",cb);
        }
    }
    on(eventName,cb){
        let eventArr = eventName.split(" ");
        // 针对多个节点绑定多个事件
        // console.log(eventArr);
        for(let i=0;i<this.length;i++){
            for(let j=0;j<eventArr.length;j++){
                this[i].addEventListener(eventArr[j],cb);
            }
        }
        return this;
    }
    eq(index){
        // return this[index];
        return new Jq(this[index],this);
    }
    end(){
        return this['prevObject']; 
    }
    get(index){
        return this[index];
    }
    css(...args){
        // console.log(arguments)
        // console.log(args);
        // 区分不同情况分别处理
        if(args.length===1){
            // 一个参数：对象和字符串情况；
            if(typeof args[0] === "object"){
                // 1 设置多个样式
                for(let i=0;i<this.length;i++){
                    // 多个元素
                    for(let j in args[0]){
                        this.#setStyle(this[i],j,args[0][j]);
                    }
                }
            }else{
                // 3 获取一个样式  : 多个元素只会获取第一个元素样式
              return this.#getStyle(this[0],args[0])
            }

        }else{
            // 2、两个参数 ：设置一个样式
            // 多个元素设置一个样式
            for(let i=0;i<this.length;i++){
                this.#setStyle(this[i],args[0],args[1]);
            }
           
        }
        return this;
    }
    #getStyle(ele,styleName){
        if(styleName in $.cssHooks){
          return $.cssHooks[styleName].get(ele);
        }
        return getComputedStyle(ele,null)[styleName];
    }  
    
    #setStyle(ele,styleName,styleValue){
        if(typeof styleValue === "number" && !$.cssNumber[styleName]){
            styleValue = styleValue + "px";
        }
        if(styleName in $.cssHooks){
            $.cssHooks[styleName].set(ele,styleValue);
        }
        ele.style[styleName] = styleValue;
    }

}

$.cssNumber = {
    animationIterationCount: true,
    columnCount: true,
    fillOpacity: true,
    flexGrow: true,
    flexShrink: true,
    fontWeight: true,
    gridArea: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnStart: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowStart: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    widows: true,
    zIndex: true,
    zoom: true
}
$.cssHooks = {};

function $(arg){
    return new Jq(arg);
}
